import './App.css';
import CCMyKitchen from './Components/CCMyKitchen';

function App() {
  return (
    <div>
      <CCMyKitchen/>
    </div>
  );
}

export default App;
